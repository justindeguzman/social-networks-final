<?php
return array (
  'Wiki page' => 'Страница Wiki',
);
