<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Sukurti</strong> naują puslapį',
  '<strong>Edit</strong> page' => '<strong>Taisyti</strong> puslapį',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Įrašykite Wiki puslapį arba adresą (pvz. http://example.com)',
  'New page title' => 'Naujo puslapio pavadinimas',
  'Page content' => 'Puslapio turinys',
  'Save' => 'Išsaugoti',
);
