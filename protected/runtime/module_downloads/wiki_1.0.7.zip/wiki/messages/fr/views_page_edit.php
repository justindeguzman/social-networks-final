<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Créer</strong> une nouvelle page',
  '<strong>Edit</strong> page' => '<strong>Editer</strong> la page',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Entrez le nom de la page ou un URL',
  'New page title' => 'Titre de la page',
  'Page content' => 'Contenu de la page',
  'Save' => 'Enregistrer',
);
